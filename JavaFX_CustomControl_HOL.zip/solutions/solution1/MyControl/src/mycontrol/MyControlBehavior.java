package mycontrol;

import com.sun.javafx.scene.control.behavior.BehaviorBase;
import javafx.scene.input.MouseEvent;


public class MyControlBehavior extends BehaviorBase<MyControl> {

    // <editor-fold defaultstate="collapsed" desc="Constructor">
    public MyControlBehavior(final MyControl CONTROL) {
        super(CONTROL);
    }
    // </editor-fold>

	// <editor-fold defaultstate="collapsed" desc="Event handling">
	@Override public void mouseEntered(final MouseEvent EVENT) {
        final MyControl     CONTROL = getControl();
		final MyControlSkin SKIN    = (MyControlSkin) CONTROL.getSkin();
	}

	@Override public void mousePressed(final MouseEvent EVENT) {
        final MyControl     CONTROL = getControl();
		final MyControlSkin SKIN    = (MyControlSkin) CONTROL.getSkin();
        System.out.println("MousePressed event");
	}

	@Override public void mouseReleased(final MouseEvent EVENT) {
        final MyControl     CONTROL = getControl();
		final MyControlSkin SKIN    = (MyControlSkin) CONTROL.getSkin();
        System.out.println("MouseReleased event");
	}

	@Override public void mouseExited(final MouseEvent EVENT) {
        final MyControl     CONTROL = getControl();
		final MyControlSkin SKIN    = (MyControlSkin) CONTROL.getSkin();
        System.out.println("MouseExited event");
	}

	@Override public void mouseDragged(final MouseEvent EVENT) {
        final MyControl     CONTROL = getControl();
		final MyControlSkin SKIN    = (MyControlSkin) CONTROL.getSkin();
        System.out.println("MouseDragged event");
	}
    // </editor-fold>
}
