package ledcontrol;

import com.sun.javafx.scene.control.skin.SkinBase;
import javafx.animation.AnimationTimer;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.effect.BlurType;
import javafx.scene.effect.DropShadow;
import javafx.scene.effect.InnerShadow;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Paint;
import javafx.scene.paint.RadialGradient;
import javafx.scene.paint.Stop;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;


public class LedSkin extends SkinBase<Led, LedBehavior> {

    // <editor-fold defaultstate="collapsed" desc="Variable definitions">
    private Led            control;
    private boolean        isDirty;
    private boolean        initialized;
    private Group          frame;
    private Group          ledOff;
    private Group          ledOn;
    private Group          highlight;
    private boolean        isOn;
    private long           lastTimerCall;
    private AnimationTimer timer;
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="Constructor">
    public LedSkin(final Led CONTROL) {
        super(CONTROL, new LedBehavior(CONTROL));
        control       = CONTROL;
        initialized   = false;
        isDirty       = false;
        frame         = new Group();
        ledOff        = new Group();
        ledOn         = new Group();
        highlight     = new Group();
        isOn          = false;
        lastTimerCall = 0l;
        timer         = new AnimationTimer() {
            @Override public void handle(long now) {
                if (now > lastTimerCall + 500000000l) {
                    isOn ^= true;
                    ledOn.setVisible(isOn);
                    lastTimerCall = now;
                }
            }
        };
        init();
    }
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="Initialization">
    private void init() {
        if (control.getPrefWidth() < 0 | control.getPrefHeight() < 0) {
            control.setPrefSize(100, 100);
        }

        frame.setVisible(control.isFrameVisible());
        ledOn.setVisible(control.isGlowing());
        if (control.isBlinking()) {
            timer.start();
        }

        // Register listeners
        registerChangeListener(control.colorProperty(), "COLOR");
        registerChangeListener(control.glowingProperty(), "GLOWING");
        registerChangeListener(control.blinkingProperty(), "BLINKING");
        registerChangeListener(control.frameVisibleProperty(), "FRAMEVISIBLE");

        addEventFilter(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>() {
            @Override public void handle(final MouseEvent EVENT) {
                getBehavior().mousePressed(EVENT);
            }
        });

        initialized = true;
        paint();
    }
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="Property related">
    @Override protected void handleControlPropertyChanged(final String PROPERTY) {
        super.handleControlPropertyChanged(PROPERTY);
        if ("COLOR".equals(PROPERTY)) {
		    drawLedOff();
            drawLedOn();
        } else if ("GLOWING".equals(PROPERTY)) {
            ledOn.setVisible(control.isGlowing());
        } else if ("BLINKING".equals(PROPERTY)) {
            if (control.isBlinking()) {
                timer.start();
            } else {
                timer.stop();
                ledOn.setVisible(false);
            }
        } else if ("FRAMEVISIBLE".equals(PROPERTY)) {
            frame.setVisible(control.isFrameVisible());
        }
    }
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="Paint">
    public final void paint() {
        if (!initialized) {
            init();
        }
        getChildren().clear();
        drawFrame();
        drawLedOff();
        drawLedOn();
        drawHighlight();

        getChildren().addAll(frame,
                             ledOff,
                             ledOn,
                             highlight);
    }
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="Layout and Size related">
    @Override public void layoutChildren() {
        if (isDirty) {
            paint();
            isDirty = false;
        }
        super.layoutChildren();
    }

    @Override public final Led getSkinnable() {
        return control;
    }

    @Override public final void dispose() {
        control = null;
    }

    @Override protected double computePrefWidth(final double PREF_WIDTH) {
        double prefWidth = 100;
        if (PREF_WIDTH != -1) {
            prefWidth = Math.max(0, PREF_WIDTH - getInsets().getLeft() - getInsets().getRight());
        }
        return super.computePrefWidth(prefWidth);
    }

    @Override protected double computePrefHeight(final double PREF_HEIGHT) {
        double prefHeight = 100;
        if (PREF_HEIGHT != -1) {
            prefHeight = Math.max(0, PREF_HEIGHT - getInsets().getTop() - getInsets().getBottom());
        }
        return super.computePrefWidth(prefHeight);
    }
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="Drawing related">
    public final void drawFrame() {
        final double SIZE = control.getPrefWidth() < control.getPrefHeight() ? control.getPrefWidth() : control.getPrefHeight();
        final double WIDTH = SIZE;
        final double HEIGHT = SIZE;

        frame.getChildren().clear();

        final Shape IBOUNDS = new Rectangle(0, 0, WIDTH, HEIGHT);
        IBOUNDS.setOpacity(0.0);
        frame.getChildren().add(IBOUNDS);

        final Circle SHAPE = new Circle(0.5 * WIDTH, 0.5 * HEIGHT, 0.35 * WIDTH);
        final Paint SHAPE_FILL = new LinearGradient(0.25 * WIDTH, 0.25 * HEIGHT,
                                                    0.7379036790187178 * WIDTH, 0.7379036790187178 * HEIGHT,
                                                    false, CycleMethod.NO_CYCLE,
                                                    new Stop(0.0, Color.color(0.0784313725, 0.0784313725, 0.0784313725, 0.6470588235)),
                                                    new Stop(0.15, Color.color(0.0784313725, 0.0784313725, 0.0784313725, 0.6470588235)),
                                                    new Stop(0.26, Color.color(0.1607843137, 0.1607843137, 0.1607843137, 0.6470588235)),
                                                    new Stop(0.26009998, Color.color(0.1607843137, 0.1607843137, 0.1607843137, 0.6431372549)),
                                                    new Stop(0.85, Color.color(0.7843137255, 0.7843137255, 0.7843137255, 0.4039215686)),
                                                    new Stop(1.0, Color.color(0.7843137255, 0.7843137255, 0.7843137255, 0.3450980392)));
        SHAPE.setFill(SHAPE_FILL);
        SHAPE.setStroke(null);

        frame.getChildren().addAll(SHAPE);
        frame.setCache(true);
    }

    public final void drawLedOff() {
        final double SIZE = control.getPrefWidth() < control.getPrefHeight() ? control.getPrefWidth() : control.getPrefHeight();
        final double WIDTH = SIZE;
        final double HEIGHT = SIZE;

        ledOff.getChildren().clear();

        final Shape IBOUNDS = new Rectangle(0, 0, WIDTH, HEIGHT);
        IBOUNDS.setOpacity(0.0);
        ledOff.getChildren().add(IBOUNDS);

        final Circle GLOW_OFF = new Circle(0.5 * WIDTH, 0.5 * HEIGHT, 0.25 * WIDTH);
        final Paint GLOW_OFF_FILL = new LinearGradient(0.33 * WIDTH, 0.33 * HEIGHT,
                                                       0.6694112549695429 * WIDTH, 0.6694112549695427 * HEIGHT,
                                                       false, CycleMethod.NO_CYCLE,
                                                       new Stop(0.0, control.getColor().darker().darker().darker()),
                                                       new Stop(0.49, control.getColor().darker().darker().darker().darker()),
                                                       new Stop(1.0, control.getColor().darker().darker().darker()));
        GLOW_OFF.setFill(GLOW_OFF_FILL);
        GLOW_OFF.setStroke(null);

        final InnerShadow GLOW_OFF_INNER_SHADOW = new InnerShadow();
        GLOW_OFF_INNER_SHADOW.setOffsetX(0.0);
        GLOW_OFF_INNER_SHADOW.setOffsetY(0.0);
        GLOW_OFF_INNER_SHADOW.setRadius(0.180 * GLOW_OFF.getLayoutBounds().getWidth());
        GLOW_OFF_INNER_SHADOW.setColor(Color.BLACK);
        GLOW_OFF_INNER_SHADOW.setBlurType(BlurType.GAUSSIAN);
        GLOW_OFF.setEffect(GLOW_OFF_INNER_SHADOW);

        ledOff.getChildren().addAll(GLOW_OFF);
        ledOff.setCache(true);
    }

    public final void drawLedOn() {
        final double SIZE = control.getPrefWidth() < control.getPrefHeight() ? control.getPrefWidth() : control.getPrefHeight();
        final double WIDTH = SIZE;
        final double HEIGHT = SIZE;

        ledOn.getChildren().clear();

        final Shape IBOUNDS = new Rectangle(0, 0, WIDTH, HEIGHT);
        IBOUNDS.setOpacity(0.0);
        ledOn.getChildren().add(IBOUNDS);

        final Circle GLOW_ON = new Circle(0.5 * WIDTH, 0.5 * HEIGHT, 0.25 * WIDTH);
        final Paint GLOW_ON_FILL = new LinearGradient(0.33 * WIDTH, 0.33 * HEIGHT,
                                                      0.6694112549695429 * WIDTH, 0.6694112549695427 * HEIGHT,
                                                      false, CycleMethod.NO_CYCLE,
                                                      new Stop(0.0, control.getColor().darker()),
                                                      new Stop(0.49, control.getColor().darker().darker()),
                                                      new Stop(1.0, control.getColor()));
        GLOW_ON.setFill(GLOW_ON_FILL);
        GLOW_ON.setStroke(null);

        final InnerShadow GLOW_ON_INNER_SHADOW = new InnerShadow();
        GLOW_ON_INNER_SHADOW.setOffsetX(0.0);
        GLOW_ON_INNER_SHADOW.setOffsetY(0.0);
        GLOW_ON_INNER_SHADOW.setRadius(0.180 * GLOW_ON.getLayoutBounds().getWidth());
        GLOW_ON_INNER_SHADOW.setColor(Color.BLACK);
        GLOW_ON_INNER_SHADOW.setBlurType(BlurType.GAUSSIAN);

        final DropShadow GLOW = new DropShadow();
        GLOW.setOffsetX(0.0);
        GLOW.setOffsetY(0.0);
        GLOW.setRadius(0.9 * GLOW_ON.getLayoutBounds().getWidth());
        GLOW.setColor(control.getColor());
        GLOW.setBlurType(BlurType.GAUSSIAN);
        GLOW.setInput(GLOW_ON_INNER_SHADOW);
        GLOW_ON.setEffect(GLOW);

        ledOn.getChildren().addAll(GLOW_ON);
        ledOn.setCache(true);
    }

    public final void drawHighlight() {
        final double SIZE = control.getPrefWidth() < control.getPrefHeight() ? control.getPrefWidth() : control.getPrefHeight();
        final double WIDTH = SIZE;
        final double HEIGHT = SIZE;

        highlight.getChildren().clear();

        final Shape IBOUNDS = new Rectangle(0, 0, WIDTH, HEIGHT);
        IBOUNDS.setOpacity(0.0);
        highlight.getChildren().add(IBOUNDS);

        final Circle SHAPE = new Circle(0.5 * WIDTH, 0.5 * HEIGHT, 0.2 * WIDTH);
        final Paint SHAPE_FILL = new RadialGradient(0, 0,
                                                    0.35 * WIDTH, 0.35 * HEIGHT,
                                                    0.205 * WIDTH,
                                                    false, CycleMethod.NO_CYCLE,
                                                    new Stop(0.0, Color.color(0.7843137255, 0.7607843137, 0.8156862745, 1)),
                                                    new Stop(1.0, Color.color(0.7843137255, 0.7607843137, 0.8156862745, 0)));
        SHAPE.setFill(SHAPE_FILL);
        SHAPE.setStroke(null);

        highlight.getChildren().addAll(SHAPE);
        highlight.setCache(true);
    }
    // </editor-fold>
}
