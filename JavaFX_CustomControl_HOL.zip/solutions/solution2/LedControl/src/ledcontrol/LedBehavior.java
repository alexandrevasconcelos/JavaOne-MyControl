package ledcontrol;

import com.sun.javafx.scene.control.behavior.BehaviorBase;
import javafx.scene.input.MouseEvent;


public class LedBehavior extends BehaviorBase<Led> {

    // <editor-fold defaultstate="collapsed" desc="Constructor">
    public LedBehavior(final Led CONTROL) {
        super(CONTROL);
    }
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="Event handling">
    @Override public void mousePressed(final MouseEvent EVENT) {
        final int NO_OF_CLICKS = EVENT.getClickCount();
        final Led CONTROL = getControl();
        switch (NO_OF_CLICKS) {
            case 1:
                if (CONTROL.isGlowing()) {
                    CONTROL.setGlowing(false);
                } else {
                    CONTROL.setGlowing(true);
                }
                break;
            case 2:
                if (CONTROL.isBlinking()) {
                    CONTROL.setBlinking(false);
                } else {
                    CONTROL.setBlinking(true);
                }
                break;
        }
        EVENT.consume();
    }
    // </editor-fold>
}

