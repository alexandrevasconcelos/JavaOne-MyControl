package ledcontrol;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;


public class LedDemo extends Application {

    @Override public void start(Stage stage) {
        Led control = LedBuilder.create()
                                .frameVisible(true)
                                .color(Color.LIME)
                                .glowing(false)
                                .blinking(false)
                                .build();
        control.setPrefSize(100, 100);

        StackPane pane = new StackPane();
        pane.getChildren().add(control);

        Scene scene = new Scene(pane, 100, 100, Color.DARKGRAY);

        stage.setTitle("JavaFX Led Code");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        Application.launch(args);
    }
}


