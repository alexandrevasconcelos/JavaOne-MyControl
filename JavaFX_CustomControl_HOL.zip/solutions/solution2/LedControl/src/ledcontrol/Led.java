package ledcontrol;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.scene.control.Control;
import javafx.scene.paint.Color;


public class Led extends Control {

    // <editor-fold defaultstate="collapsed" desc="Variable definitions">
    private static final String   DEFAULT_STYLE_CLASS = "led";
    private ObjectProperty<Color> color;
    private BooleanProperty       blinking;
    private BooleanProperty       glowing;
    private BooleanProperty       frameVisible;
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="Constructor">
    public Led() {
        color        = new SimpleObjectProperty<>(Color.web("#FF0000"));
        glowing      = new SimpleBooleanProperty(false);
        blinking     = new SimpleBooleanProperty(false);
        frameVisible = new SimpleBooleanProperty(true);

        init();
    }
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="Initialization">
    private void init() {
        getStyleClass().add(DEFAULT_STYLE_CLASS);
    }
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="Getters and Setters">
    public final Color getColor() {
        return color.get();
    }

    public final void setColor(final Color COLOR) {
        color.set(COLOR);
    }

    public final ObjectProperty<Color> colorProperty() {
        return color;
    }

    public final boolean isBlinking() {
        return blinking.get();
    }

    public final void setBlinking(final boolean BLINKING) {
        blinking.set(BLINKING);
    }

    public final BooleanProperty blinkingProperty() {
        return blinking;
    }

    public final boolean isGlowing() {
        return glowing.get();
    }

    public final void setGlowing(final boolean GLOWING) {
        glowing.set(GLOWING);
    }

    public final BooleanProperty glowingProperty() {
        return glowing;
    }

    public final boolean isFrameVisible() {
        return frameVisible.get();
    }

    public final void setFrameVisible(final boolean FRAME_VISIBLE) {
        frameVisible.set(FRAME_VISIBLE);
    }

    public final BooleanProperty frameVisibleProperty() {
        return frameVisible;
    }
    //</editor-fold>

    // <editor-fold defaultstate="collapsed" desc="Size related">
    @Override public void setPrefSize(final double WIDTH, final double HEIGHT) {
        final double SIZE = WIDTH < HEIGHT ? WIDTH : HEIGHT;
        super.setPrefSize(SIZE, SIZE);
    }
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="Style related">
    @Override protected String getUserAgentStylesheet() {
        return getClass().getResource(getClass().getSimpleName().toLowerCase() + ".css").toExternalForm();
    }
    // </editor-fold>
}
