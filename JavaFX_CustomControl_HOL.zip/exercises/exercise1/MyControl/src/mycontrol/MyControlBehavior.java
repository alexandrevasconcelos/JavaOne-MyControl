package mycontrol;

import com.sun.javafx.scene.control.behavior.BehaviorBase;
import javafx.scene.input.MouseEvent;


public class MyControlBehavior extends BehaviorBase<MyControl> {

    public MyControlBehavior(final MyControl CONTROL) {
        super(CONTROL);
    }

    // <editor-fold defaultstate="collapsed" desc="Constructor">

    // </editor-fold>

	// <editor-fold defaultstate="collapsed" desc="Event handling">

    // </editor-fold>
}
