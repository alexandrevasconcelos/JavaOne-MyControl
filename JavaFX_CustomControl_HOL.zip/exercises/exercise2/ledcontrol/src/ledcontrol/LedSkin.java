package ledcontrol;

import com.sun.javafx.scene.control.skin.SkinBase;


public class LedSkin extends SkinBase<Led, LedBehavior> {

    // <editor-fold defaultstate="collapsed" desc="Variable definitions">
    private Led            control;
    private boolean        isDirty;
    private boolean        initialized;
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="Constructor">
    public LedSkin(final Led CONTROL) {
        super(CONTROL, new LedBehavior(CONTROL));
        control       = CONTROL;
        initialized   = false;
        isDirty       = false;
        init();
    }
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="Initialization">
    private void init() {
        if (control.getPrefWidth() < 0 | control.getPrefHeight() < 0) {
            control.setPrefSize(100, 100);
        }

        // Register listeners
        registerChangeListener(control.colorProperty(), "COLOR");

        initialized = true;
        paint();
    }
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="Property related">
    @Override protected void handleControlPropertyChanged(final String PROPERTY) {
        super.handleControlPropertyChanged(PROPERTY);
        if ("COLOR".equals(PROPERTY)) {

        }
    }
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="Paint">
    public final void paint() {
        if (!initialized) {
            init();
        }
        getChildren().clear();

        getChildren().addAll();
    }
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="Layout and Size related">
    @Override public void layoutChildren() {
        if (isDirty) {
            paint();
            isDirty = false;
        }
        super.layoutChildren();
    }

    @Override public final Led getSkinnable() {
        return control;
    }

    @Override public final void dispose() {
        control = null;
    }

    @Override protected double computePrefWidth(final double PREF_WIDTH) {
        double prefWidth = 100;
        if (PREF_WIDTH != -1) {
            prefWidth = Math.max(0, PREF_WIDTH - getInsets().getLeft() - getInsets().getRight());
        }
        return super.computePrefWidth(prefWidth);
    }

    @Override protected double computePrefHeight(final double PREF_HEIGHT) {
        double prefHeight = 100;
        if (PREF_HEIGHT != -1) {
            prefHeight = Math.max(0, PREF_HEIGHT - getInsets().getTop() - getInsets().getBottom());
        }
        return super.computePrefWidth(prefHeight);
    }
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="Drawing related">

    // </editor-fold>
}
