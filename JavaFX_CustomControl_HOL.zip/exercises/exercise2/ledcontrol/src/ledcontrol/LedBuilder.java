package ledcontrol;

import java.util.HashMap;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.Property;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.scene.control.ControlBuilder;
import javafx.scene.paint.Color;
import javafx.util.Builder;


public class LedBuilder<B extends LedBuilder<B>> extends ControlBuilder<B> implements Builder<Led> {

    // <editor-fold defaultstate="collapsed" desc="Variable definitions">
    private HashMap<String, Property> properties = new HashMap<>();
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="Constructor">
    protected LedBuilder() {}
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="Methods">
    @Override public final Led build() {
        final Led CONTROL = new Led();
        return CONTROL;
    }
    // </editor-fold>
}

