package ledcontrol;

import com.sun.javafx.scene.control.behavior.BehaviorBase;
import javafx.scene.input.MouseEvent;


public class LedBehavior extends BehaviorBase<Led> {

    // <editor-fold defaultstate="collapsed" desc="Constructor">
    public LedBehavior(final Led CONTROL) {
        super(CONTROL);
    }
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="Event handling">
    
    // </editor-fold>
}

