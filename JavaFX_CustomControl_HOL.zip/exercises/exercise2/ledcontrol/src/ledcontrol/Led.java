package ledcontrol;

import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.scene.control.Control;
import javafx.scene.paint.Color;


public class Led extends Control {

    // <editor-fold defaultstate="collapsed" desc="Variable definitions">
    private static final String   DEFAULT_STYLE_CLASS = "led";
    private ObjectProperty<Color> color;
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="Constructor">
    public Led() {
        color        = new SimpleObjectProperty<>(Color.web("#FF0000"));
        init();
    }
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="Initialization">
    private void init() {
        getStyleClass().add(DEFAULT_STYLE_CLASS);
    }
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="Getters and Setters">
    public final Color getColor() {
        return color.get();
    }

    public final void setColor(final Color COLOR) {
        color.set(COLOR);
    }

    public final ObjectProperty<Color> colorProperty() {
        return color;
    }
    //</editor-fold>

    // <editor-fold defaultstate="collapsed" desc="Size related">
    
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="Style related">
    @Override protected String getUserAgentStylesheet() {
        return getClass().getResource(getClass().getSimpleName().toLowerCase() + ".css").toExternalForm();
    }
    // </editor-fold>
}
